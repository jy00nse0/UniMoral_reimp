---
task_categories:
- text-classification
- zero-shot-classification
- translation
- text2text-generation
- text-generation
language:
- ar
- zh
- en
- hi
- ru
- es
tags:
- moral
- reasoning
- morality
- culture
- multilingual
size_categories:
- 1K<n<10K
---

# UniMoral: A unified dataset for multilingual moral reasoning

UniMoral is a multilingual dataset designed to study moral reasoning as a computational pipeline. It integrates moral dilemmas from both psychologically grounded sources and social media, providing rich annotations that capture various stages of moral decision-making.

Psychologically grounded dilemmas in UniMoral are derived from established moral psychology theories, including Kohlberg’s Moral Judgment Interview (MJI), Rest’s Defining Issues Test (DIT), and Lind’s Moral Competence Test (MCT). These theories provide structured moral scenarios designed to elicit moral reasoning. To expand the dataset, LLaMA-3.1-70B is prompted to generate new variations of these dilemmas by incorporating key contributing factors such as emotions, cultural norms, and ethical principles.

Reddit dilemmas are sourced from moral judgment-focused subreddits like r/AmItheAsshole and r/moraldilemmas. Posts are rephrased into standardized moral dilemmas using LLaMA-3.3-70B, which also generates mutually exclusive action choices. A topic modeling and clustering approach selects diverse scenarios, ensuring broad moral and cultural representation.

## Key Features

- Multilingual Coverage: Spanning six languages: Arabic, Chinese, English, Hindi, Russian, and Spanish, to ensure cultural diversity in moral reasoning.
      - The dataset has 12 files: 1 long + 1 short for each of the 6 languages
      - The 'long' file contains all the annotations described below whereas the 'short' file contains only 1 and 6 out of the below.
- Comprehensive Annotations: Each file for 'long' annotations includes the following for each moral scenario:
      1. Action choices made by annotators
      2. Ethical principles guiding decisions (e.g., deontology, utilitarianism)
      3. Contributing factors influencing decisions (e.g., emotions, cultural values, legal considerations)
      4. Contributing emotion(s) influencing decisions
      5. Consequences of the chosen actions
      6. Annotators' moral and cultural profiles, including responses to standardized moral and cultural value questionnaires (MFQ2 and VSM 2013)

## Important Columns:

While all the columns in the files may be self evident based on their name, we explain some of them below:
- Scenario_id: Corresponding to psychological dilemmas formatted as type(long/short)_count_theory_contributingFactor
- Annotator_id: Prolific assigned annotator id
- Selected_action: The index of the action selected from Possible_actions
- Action_criteria: Likert scale rating corresponding to four ethical frameworks -- Deontology, Utilitarianism, Rights-based, and Virtuous.
- Contributing_factors: Likert scale rating corresponding to eight contributing factors -- Emotions, Moral, Culture, Responsibilities, Relationships, Legality, Politeness, and Sacred values.
- Moral_values: Annotator's aggregated moral values from MFQ2
- Cultural_values: Annotator's aggregated cultural values from VSM 2013.

## Citation
If you use the dataset in your work, please cite the following paper:
```
@inproceedings{kumar-jurgens-2025-rules,
    title = "Are Rules Meant to be Broken? Understanding Multilingual Moral Reasoning as a Computational Pipeline with {U}ni{M}oral",
    author = "Kumar, Shivani  and
      Jurgens, David",
    editor = "Che, Wanxiang  and
      Nabende, Joyce  and
      Shutova, Ekaterina  and
      Pilehvar, Mohammad Taher",
    booktitle = "Proceedings of the 63rd Annual Meeting of the Association for Computational Linguistics (Volume 1: Long Papers)",
    month = jul,
    year = "2025",
    address = "Vienna, Austria",
    publisher = "Association for Computational Linguistics",
    url = "https://aclanthology.org/2025.acl-long.294/",
    doi = "10.18653/v1/2025.acl-long.294",
    pages = "5890--5912",
    ISBN = "979-8-89176-251-0"
}
```